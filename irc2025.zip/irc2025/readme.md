**_The IRC 2025 Repository of Project Kratos_**
